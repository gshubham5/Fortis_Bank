package bus;

public interface IOperation {

}
