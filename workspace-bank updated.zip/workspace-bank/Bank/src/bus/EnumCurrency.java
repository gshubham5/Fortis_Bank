package bus;

public enum EnumCurrency {
	USD,
	INR,
	GBP,
	UNDEFINED
}
