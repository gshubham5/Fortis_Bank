package bus;

public enum EnumTransactionType {
	DEPOSIT,
	WITHDRAW,
	UNDEFINED
}
